let emailData = { address: "", id: "", token: "" };

document.getElementById("generateBtn").addEventListener("click", async () => {
  const res = await fetch("https://api.mail.tm/accounts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      address: `user${Math.floor(Math.random() * 99999)}@mail.tm`,
      password: "tempmail123"
    })
  });

  const data = await res.json();
  emailData.address = data.address;
  emailData.id = data.id;

  const tokenRes = await fetch("https://api.mail.tm/token", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      address: data.address,
      password: "tempmail123"
    })
  });

  const tokenData = await tokenRes.json();
  emailData.token = tokenData.token;

  document.getElementById("emailAddress").value = emailData.address;
  document.getElementById("messageList").innerHTML = "<li>Waiting for messages...</li>";

  pollInbox();
});

function copyEmail() {
  const input = document.getElementById("emailAddress");
  navigator.clipboard.writeText(input.value);
  alert("Copied: " + input.value);
}

function pollInbox() {
  const interval = setInterval(async () => {
    const inboxRes = await fetch("https://api.mail.tm/messages", {
      headers: { Authorization: `Bearer ${emailData.token}` }
    });
    const inbox = await inboxRes.json();

    if (inbox["hydra:member"].length > 0) {
      const list = document.getElementById("messageList");
      list.innerHTML = "";
      inbox["hydra:member"].forEach((msg) => {
        const li = document.createElement("li");
        li.innerHTML = `<strong>${msg.from.address}</strong><br>${msg.subject}`;
        list.appendChild(li);
      });
    }
  }, 10000);
}